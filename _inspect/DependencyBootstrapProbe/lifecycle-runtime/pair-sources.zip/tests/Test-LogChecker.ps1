$ErrorActionPreference = 'Stop'
$fixtureRoot = Join-Path $PSScriptRoot 'log-fixtures\identity-tests'
$checker = Join-Path $PSScriptRoot '..\Check-Run.ps1'
$paths = @('BepInEx\patchers\DependencyBootstrapProbe.Patcher.dll','BepInEx\plugins\DependencyBootstrapProbe_Serp\DependencyBootstrapProbe.dll','BepInEx\core\BepInEx.dll','BepInEx\plugins\000shcdese\SHCDESE.dll')
$hashes = @()
foreach ($relative in $paths) {
    $target = Join-Path $fixtureRoot $relative
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
    # Plain fixture bytes, deliberately not usable game assemblies.
    $bytes = [Text.Encoding]::UTF8.GetBytes('SYNTHETIC LOG TEST ONLY: ' + $relative)
    [IO.File]::WriteAllBytes($target,$bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $hashes += [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','') } finally { $sha.Dispose() }
}
$start = '[DBP:SESSION] id=synthetic'
$details = @{
    MODE='Active'; READY_OBSERVED='mode=Active; fixture'
    FINISH="mode=Active patcher=$($hashes[0])"; CORE_BINARY="sha256=$($hashes[2])"; SE_BINARY="sha256=$($hashes[3])"
    PLUGIN_AWAKE="plugin=$($hashes[1]) static render observer attached"; PLUGIN_DISABLED="plugin=$($hashes[1])"
    BEFORE_EXTENDER='snapshot=True type=fixture'; COMPATIBILITY_ENTER='count=1'; CHAIN_COMPLETE='snapshot=True extender=True checks=1'
    POST_CLEANUP_RENDER='original Unity component destroyed; distinct render frames=120'
}
$sequence = @('FINISH','MODE','LISTENER_ATTACHED','READY_OBSERVED','CHAIN_PREPARE','CORE_BINARY','CHAIN_TRANSFORMED','CHAIN_DELEGATE_BEGIN','CHAIN_DELEGATE_END','CHAIN_JIT_BEGIN','CHAIN_JIT_END','CHAIN_COPY_COMPILED','CHAIN_INSTALL','CHAIN_HOOK_INSTALLED','CHAIN_ENTER','SNAPSHOT','BEFORE_EXTENDER','SE_BINARY','SE_PREPARE','SE_TRANSFORMED','SE_DELEGATE_BEGIN','SE_DELEGATE_END','SE_JIT_BEGIN','SE_JIT_END','SE_COPY_COMPILED','SE_INSTALL','SE_HOOK_INSTALLED','COMPATIBILITY_ENTER','PLUGIN_AWAKE','CHAIN_COMPLETE','POST_CLEANUP_RENDER')
$active = @($start) + @($sequence | ForEach-Object { "[Info:fixture] [DBP:$_] $($details[$_])" })
$disabled = @($start,"[Info:fixture] [DBP:FINISH] $($details.FINISH.Replace('mode=Active','mode=Disabled'))",'[Info:fixture] [DBP:DISABLED] restart','[DBP:LISTENER_ATTACHED] fixture','[DBP:READY_OBSERVED] mode=Disabled;',"[Info:fixture] [DBP:PLUGIN_DISABLED] $($details.PLUGIN_DISABLED)",'[Info:fixture] [DBP:CHAIN_COMPLETE] snapshot=False extender=False checks=0')
function CheckFixture([string]$name,[string[]]$lines,[string]$mode,[bool]$accept) {
    $file = Join-Path $fixtureRoot ($name+'.log')
    [IO.File]::WriteAllLines($file,$lines)
    $passed = $false
    try { & $checker -Mode $mode -LogPath $file -ExpectedArtifactRoot $fixtureRoot -GameDir $fixtureRoot; $passed=$true } catch { if ($accept) { throw } }
    if ($passed -ne $accept) { throw "Unexpected log-check outcome: $name" }
    Write-Host "PASS synthetic log case: $name (accepted=$accept)"
}
CheckFixture 'active' $active Active $true
CheckFixture 'disabled' $disabled Disabled $true
CheckFixture 'missing-se-copy' @($active | Where-Object { $_ -notmatch '\[DBP:SE_COPY_COMPILED\]' }) Active $false
CheckFixture 'missing-awake' @($active | Where-Object { $_ -notmatch '\[DBP:PLUGIN_AWAKE\]' }) Active $false
CheckFixture 'duplicate-awake' @($active + ($active | Where-Object { $_ -match '\[DBP:PLUGIN_AWAKE\]' })) Active $false
CheckFixture 'duplicate-post' @($active + $active[-1]) Active $false
CheckFixture 'stale-patcher' @($active | ForEach-Object { $_.Replace($hashes[0],('0'*64)) }) Active $false
CheckFixture 'stale-plugin' @($active | ForEach-Object { $_.Replace($hashes[1],('0'*64)) }) Active $false
CheckFixture 'stale-core' @($active | ForEach-Object { $_.Replace($hashes[2],('0'*64)) }) Active $false
CheckFixture 'last-start-empty' @($active + $start) Active $false
CheckFixture 'error' @($active + '[Info:fixture] [DBP:ERROR] synthetic failure') Active $false
CheckFixture 'skip' @($active + '[Info:fixture] [DBP:SKIP] unknown binary') Active $false
CheckFixture 'wrong-count' @($active | ForEach-Object { $_.Replace('checks=1','checks=2') }) Active $false
CheckFixture 'too-few-frames' @($active | ForEach-Object { $_.Replace('frames=120','frames=119') }) Active $false
CheckFixture 'post-before-awake' (@($start,$active[-1]) + @($active[1..($active.Count-2)])) Active $false
CheckFixture 'active-in-disabled' @($disabled + '[Info:fixture] [DBP:CHAIN_HOOK_INSTALLED] unexpected') Disabled $false
CheckFixture 'disabled-as-active' $disabled Active $false
CheckFixture 'active-as-disabled' $active Disabled $false
Write-Host 'Synthetic fixtures only: this does not certify a game run.'
$observe = @($start,"[DBP:FINISH] mode=Observe patcher=$($hashes[0])",'[DBP:MODE] Observe','[DBP:LISTENER_ATTACHED] fixture','[DBP:READY_OBSERVED] mode=Observe; fixture',"[DBP:PLUGIN_AWAKE] $($details.PLUGIN_AWAKE)",'[DBP:CHAIN_COMPLETE] snapshot=False extender=False checks=0',"[DBP:POST_CLEANUP_RENDER] $($details.POST_CLEANUP_RENDER)")
CheckFixture 'observe' $observe Observe $true
CheckFixture 'observe-hook' @($observe + '[DBP:CHAIN_INSTALL] unexpected') Observe $false
CheckFixture 'observe-missing-ready' @($observe | Where-Object {$_ -notmatch 'READY_OBSERVED'}) Observe $false
CheckFixture 'observe-duplicate-ready' @($observe + '[DBP:READY_OBSERVED] mode=Observe;') Observe $false
CheckFixture 'observe-old-build' @($observe | ForEach-Object {$_.Replace($hashes[0],('0'*64))}) Observe $false
$shadow = @($active | ForEach-Object {
    if ($_ -match '\[DBP:SNAPSHOT\]') { '[DBP:SNAPSHOT] selected=1' } else { $_ }
    if ($_ -match '\[DBP:CHAIN_PREPARE\]') { '[DBP:SHADOW_REQUIRED] stage=2' }
    if ($_ -match '\[DBP:COMPATIBILITY_ENTER\]') {
        '[DBP:SHADOW_BEGIN] read-only; failures=0'
        '[DBP:SHADOW_INDEX] {"guid":"root","version":"1.0"}'
        '[DBP:SHADOW_CANDIDATE] {"guid":"nested","version":"1.0","path":"C:/fixture.dll","state":"Eligible","reason":"fixture"}'
        '[DBP:SHADOW_DEPENDENCY] {"consumer":"root","dependency":"nested","originalIssue":true,"shadowIssue":false}'
        '[DBP:SHADOW_COMPLETE] candidates=1 original=1 added=1 dependencies=1 issuesBefore=1 issuesAfter=0 originalUnchanged=True'
    }
})
CheckFixture 'shadow-valid' $shadow Active $true
CheckFixture 'shadow-missing-summary' @($shadow | Where-Object { $_ -notmatch '\[DBP:SHADOW_COMPLETE\]' }) Active $false
CheckFixture 'shadow-missing-candidate' @($shadow | Where-Object { $_ -notmatch '\[DBP:SHADOW_CANDIDATE\]' }) Active $false
CheckFixture 'shadow-wrong-count' @($shadow | ForEach-Object { $_.Replace('added=1','added=2') }) Active $false
CheckFixture 'shadow-original-mutated' @($shadow | ForEach-Object { $_.Replace('originalUnchanged=True','originalUnchanged=False') }) Active $false
CheckFixture 'shadow-overwrites-original' @($shadow | ForEach-Object { if ($_ -match 'SHADOW_INDEX') { $_.Replace('root','nested') } else { $_ } }) Active $false
CheckFixture 'shadow-error' @($shadow + '[DBP:ERROR] shadow callback failed') Active $false
CheckFixture 'shadow-duplicate-summary' @($shadow + ($shadow | Where-Object { $_ -match 'SHADOW_COMPLETE' })) Active $false
$oldActive = Join-Path $fixtureRoot 'active.log'
$rejected = $false
try { & $checker -Mode Active -RequireShadow -LogPath $oldActive -ExpectedArtifactRoot $fixtureRoot -GameDir $fixtureRoot } catch { $rejected = $true }
if (-not $rejected) { throw 'Stage-1 log accepted as shadow proof.' }
Write-Host 'PASS synthetic log case: stage-1 cannot pass required shadow check'
$controlDir=Join-Path $fixtureRoot 'BepInEx\plugins\DependencyBootstrapProbeControl_Serp'
[IO.Directory]::CreateDirectory($controlDir)|Out-Null
$controlText='{"GUID":"control","Dependencies":[{"GUID":"missing"},{"GUID":"nested","MinimumVersion":"2.0"},{"GUID":"nested","MaximumVersion":"0.0"}]}'
[IO.File]::WriteAllText((Join-Path $controlDir 'info.json'),$controlText)
$sha=[Security.Cryptography.SHA256]::Create()
try{$controlHash=[BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes((Join-Path $controlDir 'info.json')))).Replace('-','')}finally{$sha.Dispose()}
[IO.Directory]::CreateDirectory((Join-Path $fixtureRoot 'trial'))|Out-Null
$receipt=@{ManifestSHA256=$controlHash;ControlGuid='control';MissingGuid='missing';ResolvedPairs=@(@{consumer='root';dependency='nested'},@{consumer='root2';dependency='nested'})}
[IO.File]::WriteAllText((Join-Path $fixtureRoot 'trial\expectations.json'),($receipt|ConvertTo-Json -Depth 5))
$correct=@($shadow | ForEach-Object {
    if($_ -match '\[DBP:SHADOW_COMPLETE\]'){
        '[DBP:SHADOW_COMPLETE] candidates=1 original=1 added=1 dependencies=5 issuesBefore=5 issuesAfter=3 originalUnchanged=True'
        '[DBP:CORRECTION_PREPARED] original=1 effective=2 added=1 expectedIssues=3'
        '[DBP:CORRECTION_APPLIED] effective=2'
        '[DBP:ORIGINAL_ISSUE] {"consumer":"control","dependency":"missing","reason":"missing"}'
        '[DBP:ORIGINAL_ISSUE] {"consumer":"control","dependency":"nested","minimum":"2.0","reason":"too old"}'
        '[DBP:ORIGINAL_ISSUE] {"consumer":"control","dependency":"nested","maximum":"0.0","reason":"too new"}'
        '[DBP:ORIGINAL_RESULT] issues=3 expected=3 correction=True'
    } else { $_ }
    if($_ -match '\[DBP:SHADOW_REQUIRED\]'){ '[DBP:CORRECTION_MODE] Enabled' }
    if($_ -match '\[DBP:SHADOW_DEPENDENCY\]'){
        '[DBP:SHADOW_DEPENDENCY] {"consumer":"root2","dependency":"nested","originalIssue":true,"shadowIssue":false}'
        '[DBP:SHADOW_DEPENDENCY] {"consumer":"control","dependency":"missing","originalIssue":true,"shadowIssue":true}'
        '[DBP:SHADOW_DEPENDENCY] {"consumer":"control","dependency":"nested","originalIssue":true,"shadowIssue":true}'
        '[DBP:SHADOW_DEPENDENCY] {"consumer":"control","dependency":"nested","originalIssue":true,"shadowIssue":true}'
    }
})
CheckFixture 'correction-valid' $correct Active $true
CheckFixture 'correction-no-apply' @($correct|Where-Object{$_ -notmatch '\[DBP:CORRECTION_APPLIED\]'}) Active $false
CheckFixture 'correction-no-result' @($correct|Where-Object{$_ -notmatch '\[DBP:ORIGINAL_RESULT\]'}) Active $false
CheckFixture 'correction-no-issue' @($correct|Where-Object{$_ -notmatch '\[DBP:ORIGINAL_ISSUE\].*"minimum"'}) Active $false
CheckFixture 'correction-fallback' @($correct+'[DBP:CORRECTION_FALLBACK] original retained') Active $false
CheckFixture 'correction-wrong-issue' @($correct|ForEach-Object{if($_ -match 'ORIGINAL_ISSUE'){ $_.Replace('"consumer":"control"','"consumer":"root"') }else{$_}}) Active $false
CheckFixture 'correction-wrong-total' @($correct|ForEach-Object{$_.Replace('issues=3 expected=3','issues=2 expected=3')}) Active $false
CheckFixture 'correction-wrong-effective' @($correct|ForEach-Object{$_.Replace('CORRECTION_APPLIED] effective=2','CORRECTION_APPLIED] effective=1')}) Active $false
CheckFixture 'correction-disabled-apply' @($correct|ForEach-Object{$_.Replace('CORRECTION_MODE] Enabled','CORRECTION_MODE] Disabled')}) Active $false
$rejected=$false
try { & $checker -Mode Active -RequireCorrection -LogPath (Join-Path $fixtureRoot 'shadow-valid.log') -ExpectedArtifactRoot $fixtureRoot -GameDir $fixtureRoot } catch { $rejected=$true }
if(-not $rejected){throw 'Shadow log passed correction acceptance.'}
Write-Host 'PASS synthetic log case: shadow alone cannot pass required correction'
$reportPath=Join-Path $fixtureRoot 'lifecycle.json'
$report=@{Schema=1;RunId=('a'*32);Complete=$true;RemovalAuthorized=$false;Errors=@();PatcherSHA256=$hashes[0];PluginSHA256=$hashes[1];CoreSHA256=$hashes[2];ExtenderSHA256=$hashes[3];WorkshopPaths=@();Maps=@();Owners=@(@{Guid='nested';Version='1.0';Path='C:/fixture.dll';SHA256=$hashes[1];State='NotFound';Claims=@();Reason='Manual installation possible'})}
function LifecycleFixture([string]$name,[bool]$accept,[string]$mutation=''){
    $pairCase=$mutation -like 'pair*'
    $savedOwners=$report.Owners
    $ownPath=[IO.Path]::GetFullPath((Join-Path $fixtureRoot $paths[1]))
    if($pairCase){$report.Owners=@(@{Guid='DependencyBootstrapProbe_Serp';Version='1.0';Path=$ownPath;SHA256=$hashes[1];State='NotFound';Claims=@();Reason='manual'})}
    [IO.File]::WriteAllText($reportPath,($report|ConvertTo-Json -Depth 8))
    Copy-Item -LiteralPath $reportPath -Destination (Join-Path $fixtureRoot ('DependencyBootstrapProbe.lifecycle.'+$report.RunId+'.json')) -Force
    $hasher=[Security.Cryptography.SHA256]::Create()
    try{$digest=[BitConverter]::ToString($hasher.ComputeHash([IO.File]::ReadAllBytes($reportPath))).Replace('-','')}finally{$hasher.Dispose()}
    $rows=@($correct|ForEach-Object{
        $_
        if($_ -match '\[DBP:BEFORE_EXTENDER\]'){
            "[DBP:LIFECYCLE_PREPARE] binary=$($hashes[3])"
            foreach($phase in @('TRANSFORMED','DELEGATE_BEGIN','DELEGATE_END','JIT_BEGIN','JIT_END','INSTALL','HOOK_INSTALLED')){"[DBP:LIFECYCLE_$phase] fixture"}
        }
    })+@("[DBP:LIFECYCLE_PATHS] run=$($report.RunId) count=0","[DBP:LIFECYCLE_STAGED] run=$($report.RunId) before deployment decision","[DBP:LIFECYCLE_REPORT] run=$($report.RunId) sha256=$digest complete=True")
    if($mutation -eq 'missing'){$rows=@($rows|Where-Object {$_ -notmatch 'LIFECYCLE_JIT_END'})}
    if($mutation -eq 'duplicate'){$rows+= $rows[-1]}
    if($mutation -eq 'wrongrun'){$rows[-1]=$rows[-1].Replace($report.RunId,('b'*32))}
    if($mutation -eq 'changedreport'){[IO.File]::AppendAllText($reportPath,' ')}
    if($mutation -eq 'order'){$rows=@($rows[-1])+$rows[0..($rows.Count-2)]}
    if($mutation -eq 'repeat'){
        $repeat=$report.Clone();$repeat.RunId='b'*32
        [IO.File]::WriteAllText($reportPath,($repeat|ConvertTo-Json -Depth 8))
        Copy-Item -LiteralPath $reportPath -Destination (Join-Path $fixtureRoot ('DependencyBootstrapProbe.lifecycle.'+$repeat.RunId+'.json')) -Force
        $hasher=[Security.Cryptography.SHA256]::Create()
        try{$repeatDigest=[BitConverter]::ToString($hasher.ComputeHash([IO.File]::ReadAllBytes($reportPath))).Replace('-','')}finally{$hasher.Dispose()}
        $rows+=@("[DBP:LIFECYCLE_PATHS] run=$($repeat.RunId) count=0","[DBP:LIFECYCLE_STAGED] run=$($repeat.RunId) before deployment decision","[DBP:LIFECYCLE_REPORT] run=$($repeat.RunId) sha256=$repeatDigest complete=True")
    }
    if($pairCase){
        $pairPath=Join-Path (Split-Path $ownPath) 'dependency-bootstrap-pair.json'
        $pair=@{Schema=1;Guid='DependencyBootstrapProbe_Serp';Version='1.0';RuntimeSHA256=$hashes[1].ToLowerInvariant();BootstrapSHA256=$hashes[0].ToLowerInvariant()}
        [IO.File]::WriteAllText($pairPath,($pair|ConvertTo-Json))
        $hasher=[Security.Cryptography.SHA256]::Create()
        try{$pairDigest=[BitConverter]::ToString($hasher.ComputeHash([IO.File]::ReadAllBytes($pairPath))).Replace('-','')}finally{$hasher.Dispose()}
        $rows=@($rows|ForEach-Object{
            if($_ -match '\[DBP:CHAIN_PREPARE\]'){"[DBP:PAIR_PREPARED] manifest=$pairDigest"}
            $_.Replace('nested','DependencyBootstrapProbe_Serp').Replace('C:/fixture.dll',$ownPath.Replace('\','\\'))
            if($_ -match '\[DBP:SNAPSHOT\]'){"[DBP:PAIR_BOUND] guid=DependencyBootstrapProbe_Serp version=1.0 runtime=$($hashes[1])"}
        })
        if($mutation -eq 'pair-missing-bound'){$rows=@($rows|Where-Object {$_ -notmatch '\[DBP:PAIR_BOUND\]'})}
        if($mutation -eq 'pair-changed'){[IO.File]::AppendAllText($pairPath,' ')}
        if($mutation -eq 'pair-rejected'){$rows+='[DBP:PAIR_REJECTED] fixture rejection'}
    }
    $file=Join-Path $fixtureRoot ($name+'.log');[IO.File]::WriteAllLines($file,$rows)
    $passed=$false
    try{& $checker -Mode Active -RequireLifecycle -RequirePair:$pairCase -LogPath $file -LifecycleReportPath $reportPath -ExpectedArtifactRoot $fixtureRoot -GameDir $fixtureRoot;$passed=$true}catch{if($accept){throw}}
    if($passed -ne $accept){throw "Unexpected lifecycle result: $name"}
    Write-Host "PASS lifecycle checker: $name"
    $report.Owners=$savedOwners
}
LifecycleFixture 'lifecycle-valid' $true
LifecycleFixture 'pair-valid' $true 'pair'
foreach($case in @('pair-missing-bound','pair-changed','pair-rejected')){LifecycleFixture $case $false $case}
LifecycleFixture 'two-original-invocations' $true 'repeat'
foreach($mutation in @('missing','duplicate','wrongrun','changedreport','order')){LifecycleFixture $mutation $false $mutation}
$report.Complete=$false;LifecycleFixture 'incomplete' $false;$report.Complete=$true
$report.PatcherSHA256='0'*64;LifecycleFixture 'old-build' $false;$report.PatcherSHA256=$hashes[0]
$report.Owners=@();LifecycleFixture 'missing-owner' $false

# Re-evaluate the real captured inventory without copying its assemblies into fixtures.
$accepted=Join-Path $PSScriptRoot '../../../_inspect/DependencyBootstrapProbe/Lifecycle-accepted-20261017-152951'
& $checker -Mode Active -RequireLifecycle -ExpectedArtifactRoot $accepted -GameDir $accepted
$real=@(Get-Content -LiteralPath (Join-Path $accepted 'BepInEx/DependencyBootstrapProbe.trace.log'))
$testLog=Join-Path $fixtureRoot 'current-inventory-missing-requirement.log'
# Preserve counts and outcomes, but remove the required pair for a present consumer.
$missing=@($real|ForEach-Object {if($_ -match '\[DBP:SHADOW_DEPENDENCY\].*SpectatorEditorBuildTest_Serp.*BugfixesAndQoL_Serp'){ $_.Replace('BugfixesAndQoL_Serp','UnexpectedProvider') }else{$_}})
[IO.File]::WriteAllLines($testLog,$missing)
$rejected=$false
try{& $checker -Mode Active -RequireLifecycle -LogPath $testLog -ExpectedArtifactRoot $accepted -GameDir $accepted}catch{$rejected=$true}
if(-not $rejected){throw 'Present consumer lost its expected requirement without rejection.'}
# Keep dependency/count bookkeeping consistent while introducing a regression.
$regression=@($real|ForEach-Object {if($_ -match '\[DBP:SHADOW_DEPENDENCY\].*PopularityTest_Serp'){ $_.Replace('"shadowIssue": false','"shadowIssue": true') }elseif($_ -match '\[DBP:SHADOW_COMPLETE\]'){ $_.Replace('issuesAfter=0','issuesAfter=1') }else{$_}})
[IO.File]::WriteAllLines($testLog,$regression)
$rejected=$false
try{& $checker -Mode Active -RequireLifecycle -LogPath $testLog -ExpectedArtifactRoot $accepted -GameDir $accepted}catch{$rejected=$true}
if(-not $rejected){throw 'Dependency regression accepted.'}
Write-Host 'PASS: absent historical consumer allowed; missing requirement for present consumer and regression rejected.'
