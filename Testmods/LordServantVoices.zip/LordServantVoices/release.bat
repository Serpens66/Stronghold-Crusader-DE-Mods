@echo off
call "%~dp0..\Shared\Tools\Release\Invoke-Release.bat" LordServantVoices /called %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
  echo.
  echo Release fehlgeschlagen. Exit Code: %EXIT_CODE%
  echo %* | findstr /I /C:"/nopause" >nul || pause
)
exit /b %EXIT_CODE%
